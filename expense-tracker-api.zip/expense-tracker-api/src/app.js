// Builds the Express app: middleware, routes and error handlers.
// (Kept separate from server.js so the app is easy to test.)
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');

const authRoutes = require('./routes/authRoutes');
const expenseRoutes = require('./routes/expenseRoutes');
const { notFound, errorHandler } = require('./middleware/errorMiddleware');

const app = express();

app.use(helmet());            // adds secure HTTP headers
app.use(cors());              // allows requests from other origins
app.use(express.json());      // parses JSON request bodies
if (process.env.NODE_ENV !== 'production') app.use(morgan('dev')); // request logger

app.get('/', (req, res) => {
  res.json({ success: true, message: 'Expense Tracker API is running' });
});

app.use('/api/auth', authRoutes);
app.use('/api/expenses', expenseRoutes);

app.use(notFound);      // handles unknown routes (404)
app.use(errorHandler);  // handles all errors in one place

module.exports = app;
