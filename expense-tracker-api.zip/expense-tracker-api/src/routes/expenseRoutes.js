// Maps expense URLs to controller functions. All routes are protected by JWT.
const express = require('express');
const {
  createExpense, getExpenses, getExpense, updateExpense, deleteExpense, getSummary,
} = require('../controllers/expenseController');
const { protect } = require('../middleware/authMiddleware');
const validate = require('../middleware/validate');
const { idRule, createRules, updateRules, listRules } = require('../validators/expenseValidators');

const router = express.Router();

router.use(protect); // everything below requires a valid token

router.get('/summary', getSummary); // must be BEFORE '/:id', otherwise "summary" is treated as an id
router.route('/')
  .get(listRules, validate, getExpenses)
  .post(createRules, validate, createExpense);
router.route('/:id')
  .get(idRule, validate, getExpense)
  .put(updateRules, validate, updateExpense)
  .delete(idRule, validate, deleteExpense);

module.exports = router;
