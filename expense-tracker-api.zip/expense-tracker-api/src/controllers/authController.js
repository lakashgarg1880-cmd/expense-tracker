// Handles registration, login and fetching the logged-in user's profile.
const User = require('../models/User');
const asyncHandler = require('../utils/asyncHandler');
const generateToken = require('../utils/generateToken');

// POST /api/auth/register  (public)
const register = asyncHandler(async (req, res) => {
  const { name, email, password } = req.body;

  const exists = await User.findOne({ email });
  if (exists) {
    res.status(400);
    throw new Error('Email is already registered');
  }

  const user = await User.create({ name, email, password }); // password hashed in the model

  res.status(201).json({
    success: true,
    message: 'User registered successfully',
    data: { id: user._id, name: user.name, email: user.email, token: generateToken(user._id) },
  });
});

// POST /api/auth/login  (public)
const login = asyncHandler(async (req, res) => {
  const { email, password } = req.body;

  const user = await User.findOne({ email }).select('+password'); // password is hidden by default
  if (!user || !(await user.matchPassword(password))) {
    res.status(401);
    throw new Error('Invalid email or password');
  }

  res.json({
    success: true,
    message: 'Login successful',
    data: { id: user._id, name: user.name, email: user.email, token: generateToken(user._id) },
  });
});

// GET /api/auth/me  (private)
const getMe = asyncHandler(async (req, res) => {
  res.json({ success: true, data: { id: req.user._id, name: req.user.name, email: req.user.email } });
});

module.exports = { register, login, getMe };
