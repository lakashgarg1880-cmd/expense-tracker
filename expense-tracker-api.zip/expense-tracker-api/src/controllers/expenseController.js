// CRUD operations for expenses + a spending summary.
// Every query includes { user: req.user._id } so users can only touch their own data.
const Expense = require('../models/Expense');
const asyncHandler = require('../utils/asyncHandler');

// POST /api/expenses  -> Create
const createExpense = asyncHandler(async (req, res) => {
  const { title, amount, category, date, note } = req.body;
  const expense = await Expense.create({ user: req.user._id, title, amount, category, date, note });
  res.status(201).json({ success: true, message: 'Expense created', data: expense });
});

// GET /api/expenses?category=Food&startDate=2026-11-01&endDate=2026-11-30&page=1&limit=10  -> Read all
const getExpenses = asyncHandler(async (req, res) => {
  const { category, startDate, endDate } = req.query;
  const page = parseInt(req.query.page, 10) || 1;
  const limit = parseInt(req.query.limit, 10) || 10;

  const filter = { user: req.user._id };
  if (category) filter.category = category;
  if (startDate || endDate) {
    filter.date = {};
    if (startDate) filter.date.$gte = new Date(startDate);
    if (endDate) {
      const end = new Date(endDate);
      // "2026-11-02" means midnight, which would hide everything spent later that day.
      // So if no time was given, extend the limit to the end of that day.
      if (!endDate.includes('T')) end.setUTCHours(23, 59, 59, 999);
      filter.date.$lte = end;
    }
  }

  const total = await Expense.countDocuments(filter);
  const expenses = await Expense.find(filter)
    .sort({ date: -1 })
    .skip((page - 1) * limit)
    .limit(limit);

  res.json({
    success: true,
    count: expenses.length,
    total,
    page,
    pages: Math.ceil(total / limit),
    data: expenses,
  });
});

// GET /api/expenses/:id  -> Read one
const getExpense = asyncHandler(async (req, res) => {
  const expense = await Expense.findOne({ _id: req.params.id, user: req.user._id });
  if (!expense) {
    res.status(404);
    throw new Error('Expense not found');
  }
  res.json({ success: true, data: expense });
});

// PUT /api/expenses/:id  -> Update
const updateExpense = asyncHandler(async (req, res) => {
  const allowed = ['title', 'amount', 'category', 'date', 'note'];
  const updates = {};
  allowed.forEach((field) => {
    if (req.body[field] !== undefined) updates[field] = req.body[field];
  });

  const expense = await Expense.findOneAndUpdate({ _id: req.params.id, user: req.user._id }, updates, {
    new: true,           // return the updated document
    runValidators: true, // apply schema rules to the update
  });
  if (!expense) {
    res.status(404);
    throw new Error('Expense not found');
  }
  res.json({ success: true, message: 'Expense updated', data: expense });
});

// DELETE /api/expenses/:id  -> Delete
const deleteExpense = asyncHandler(async (req, res) => {
  const expense = await Expense.findOneAndDelete({ _id: req.params.id, user: req.user._id });
  if (!expense) {
    res.status(404);
    throw new Error('Expense not found');
  }
  res.json({ success: true, message: 'Expense deleted' });
});

// GET /api/expenses/summary  -> total spent + breakdown per category (MongoDB aggregation)
const getSummary = asyncHandler(async (req, res) => {
  const byCategory = await Expense.aggregate([
    { $match: { user: req.user._id } },
    { $group: { _id: '$category', total: { $sum: '$amount' }, count: { $sum: 1 } } },
    { $sort: { total: -1 } },
  ]);

  const grandTotal = byCategory.reduce((sum, c) => sum + c.total, 0);

  res.json({
    success: true,
    data: {
      grandTotal: Math.round(grandTotal * 100) / 100,
      byCategory: byCategory.map((c) => ({
        category: c._id,
        total: Math.round(c.total * 100) / 100,
        count: c.count,
      })),
    },
  });
});

module.exports = { createExpense, getExpenses, getExpense, updateExpense, deleteExpense, getSummary };
