// Single source of truth for allowed expense categories.
const CATEGORIES = ['Food', 'Transport', 'Shopping', 'Bills', 'Entertainment', 'Health', 'Education', 'Other'];

module.exports = { CATEGORIES };
