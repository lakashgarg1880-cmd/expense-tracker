// Input rules for expense endpoints.
const { body, param, query } = require('express-validator');
const { CATEGORIES } = require('../constants/categories');

const idRule = [param('id').isMongoId().withMessage('Invalid expense ID')];

const createRules = [
  body('title').trim().notEmpty().withMessage('Title is required').isLength({ max: 100 }),
  body('amount').isFloat({ gt: 0 }).withMessage('Amount must be a number greater than 0'),
  body('category').optional().isIn(CATEGORIES).withMessage(`Category must be one of: ${CATEGORIES.join(', ')}`),
  body('date').optional().isISO8601({ strict: true }).withMessage('Date must be a valid date (YYYY-MM-DD)'),
  body('note').optional().isLength({ max: 500 }),
];

const updateRules = [
  ...idRule,
  body('title').optional().trim().notEmpty().withMessage('Title cannot be empty').isLength({ max: 100 }),
  body('amount').optional().isFloat({ gt: 0 }).withMessage('Amount must be a number greater than 0'),
  body('category').optional().isIn(CATEGORIES).withMessage(`Category must be one of: ${CATEGORIES.join(', ')}`),
  body('date').optional().isISO8601({ strict: true }).withMessage('Date must be a valid date (YYYY-MM-DD)'),
  body('note').optional().isLength({ max: 500 }),
];

const listRules = [
  query('category').optional().isIn(CATEGORIES).withMessage('Invalid category'),
  query('startDate').optional().isISO8601({ strict: true }).withMessage('startDate must be a valid date (YYYY-MM-DD)'),
  query('endDate').optional().isISO8601({ strict: true }).withMessage('endDate must be a valid date (YYYY-MM-DD)'),
  query('page').optional().isInt({ min: 1 }).withMessage('page must be 1 or more'),
  query('limit').optional().isInt({ min: 1, max: 100 }).withMessage('limit must be between 1 and 100'),
];

module.exports = { idRule, createRules, updateRules, listRules };
