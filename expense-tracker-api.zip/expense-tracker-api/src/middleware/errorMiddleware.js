// Central error handling: every error in the app ends up here.
const notFound = (req, res, next) => {
  res.status(404);
  next(new Error(`Route not found: ${req.method} ${req.originalUrl}`));
};

// eslint-disable-next-line no-unused-vars
const errorHandler = (err, req, res, next) => {
  // Errors from Express itself (e.g. bad JSON body) carry their own status.
  let status = err.status || err.statusCode || (res.statusCode !== 200 ? res.statusCode : 500);
  let message = err.message || 'Server error';

  if (err.type === 'entity.parse.failed') {       // malformed JSON body
    status = 400;
    message = 'Invalid JSON in request body';
  } else if (err.code === 11000) {                // duplicate key (e.g. email already used)
    status = 400;
    message = 'Email is already registered';
  } else if (err.name === 'ValidationError') {    // Mongoose schema validation
    status = 400;
    message = Object.values(err.errors).map((e) => e.message).join(', ');
  } else if (err.name === 'CastError') {          // wrong type, e.g. invalid MongoDB id
    status = 400;
    message = `Invalid value for "${err.path}"`;
  } else if (err.name === 'JsonWebTokenError') {
    status = 401;
    message = 'Invalid token';
  } else if (err.name === 'TokenExpiredError') {
    status = 401;
    message = 'Token expired, please log in again';
  }

  // Never leak internal error text for unexpected server errors in production.
  if (status >= 500 && process.env.NODE_ENV === 'production') message = 'Server error';

  res.status(status).json({
    success: false,
    message,
    // Stack traces only in development (safe even if NODE_ENV is not set).
    stack: process.env.NODE_ENV === 'development' ? err.stack : undefined,
  });
};

module.exports = { notFound, errorHandler };
