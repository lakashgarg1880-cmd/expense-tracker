// Expense schema: each expense belongs to exactly one user.
const mongoose = require('mongoose');
const { CATEGORIES } = require('../constants/categories');

const expenseSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    title: { type: String, required: [true, 'Title is required'], trim: true, maxlength: 100 },
    amount: { type: Number, required: [true, 'Amount is required'], min: [0.01, 'Amount must be greater than 0'] },
    category: { type: String, enum: CATEGORIES, default: 'Other' },
    date: { type: Date, default: Date.now },
    note: { type: String, trim: true, maxlength: 500 },
  },
  { timestamps: true }
);

module.exports = mongoose.model('Expense', expenseSchema);
