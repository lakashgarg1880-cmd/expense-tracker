# 💸 Expense Tracker API

A RESTful backend API for tracking personal expenses, built with **Node.js, Express.js, MongoDB (Mongoose)** and **JWT authentication**. Each user registers, logs in, and can only see and manage their own expenses.

## ✨ Features

- User registration and login
- Passwords hashed with **bcrypt** (via `bcryptjs`)
- **JWT** authentication protecting all private routes
- Full **CRUD** for expenses (Create, Read, Update, Delete)
- Filtering by category and date range, plus pagination
- Spending **summary** (total + per-category breakdown) using MongoDB aggregation
- Input validation (`express-validator`) and centralized error handling
- Secure HTTP headers (`helmet`), CORS, request logging (`morgan`)
- Environment variables for secrets

## 🛠 Technologies Used

| Technology | Purpose |
|---|---|
| Node.js + Express.js | Server and REST API |
| MongoDB + Mongoose | Database and data modelling |
| bcryptjs | Password hashing |
| jsonwebtoken | JWT authentication |
| express-validator | Input validation |
| dotenv | Environment variables |
| helmet, cors, morgan | Security, cross-origin access, logging |
| nodemon | Auto-restart during development |

## 📁 Folder Structure

```
expense-tracker-api/
├── server.js                  # Entry point: connects DB and starts server
├── package.json
├── .env.example               # Template for environment variables
├── .gitignore
├── README.md
└── src/
    ├── app.js                 # Express app, middleware and route mounting
    ├── config/
    │   └── db.js              # MongoDB connection
    ├── models/
    │   ├── User.js            # User schema (+ password hashing)
    │   └── Expense.js         # Expense schema
    ├── controllers/
    │   ├── authController.js  # register, login, me
    │   └── expenseController.js # CRUD + summary logic
    ├── routes/
    │   ├── authRoutes.js      # /api/auth/*
    │   └── expenseRoutes.js   # /api/expenses/*
    ├── middleware/
    │   ├── authMiddleware.js  # JWT protection
    │   ├── validate.js        # Returns validation errors
    │   └── errorMiddleware.js # 404 + global error handler
    ├── validators/
    │   ├── authValidators.js
    │   └── expenseValidators.js
    └── utils/
        ├── asyncHandler.js    # Forwards async errors to error middleware
        └── generateToken.js   # Creates JWTs
```

## ⚙️ Installation

**Prerequisites:** [Node.js](https://nodejs.org) v18+ and MongoDB (local install or a free [MongoDB Atlas](https://www.mongodb.com/atlas) cluster).

```bash
git clone https://github.com/<your-username>/expense-tracker-api.git
cd expense-tracker-api
npm install
```

## 🔐 Environment Variables

Copy the example file and edit it:

```bash
cp .env.example .env        # Windows (cmd): copy .env.example .env
```

| Variable | Description | Example |
|---|---|---|
| `PORT` | Port the server listens on | `5000` |
| `MONGO_URI` | MongoDB connection string | `mongodb://127.0.0.1:27017/expense_tracker` |
| `JWT_SECRET` | Long random secret used to sign tokens | `my_super_secret_key_123` |
| `JWT_EXPIRES_IN` | Token lifetime | `7d` |
| `NODE_ENV` | `development` or `production` | `development` |

## ▶️ Running the Project

```bash
npm run dev     # development (auto-restart with nodemon)
npm start       # production
```

The API runs at `http://localhost:5000`.

### Testing

With the server running, open a second terminal and run:

```bash
npm test
```

This runs a smoke test that calls every endpoint and prints PASS/FAIL for each check.

## 📚 API Documentation

Base URL: `http://localhost:5000/api`

### Auth

| Method | Endpoint | Access | Description |
|---|---|---|---|
| POST | `/auth/register` | Public | Create an account |
| POST | `/auth/login` | Public | Log in and get a token |
| GET | `/auth/me` | Private | Get logged-in user's profile |

### Expenses (all require `Authorization: Bearer <token>`)

| Method | Endpoint | Description |
|---|---|---|
| POST | `/expenses` | Create an expense |
| GET | `/expenses` | List expenses (filters: `category`, `startDate`, `endDate`, `page`, `limit`) |
| GET | `/expenses/summary` | Total and per-category summary |
| GET | `/expenses/:id` | Get one expense |
| PUT | `/expenses/:id` | Update an expense |
| DELETE | `/expenses/:id` | Delete an expense |

Allowed categories: `Food, Transport, Shopping, Bills, Entertainment, Health, Education, Other`

## 🧪 Example Requests & Responses

### Register — `POST /api/auth/register`
```json
{ "name": "Asha", "email": "asha@example.com", "password": "secret123" }
```
Response `201`:
```json
{
  "success": true,
  "message": "User registered successfully",
  "data": { "id": "665f1c...", "name": "Asha", "email": "asha@example.com", "token": "eyJhbGciOi..." }
}
```

### Login — `POST /api/auth/login`
```json
{ "email": "asha@example.com", "password": "secret123" }
```
Response `200`: same shape as register, with `"message": "Login successful"`.

### Create expense — `POST /api/expenses`
Header: `Authorization: Bearer <token>`
```json
{ "title": "Lunch", "amount": 250, "category": "Food", "date": "2026-11-02", "note": "Canteen" }
```
Response `201`:
```json
{
  "success": true,
  "message": "Expense created",
  "data": {
    "_id": "665f2a...", "user": "665f1c...", "title": "Lunch", "amount": 250,
    "category": "Food", "date": "2026-11-02T00:00:00.000Z", "note": "Canteen"
  }
}
```

### List expenses — `GET /api/expenses?category=Food&page=1&limit=5`
```json
{ "success": true, "count": 1, "total": 1, "page": 1, "pages": 1, "data": [ { "title": "Lunch", "amount": 250 } ] }
```

### Update expense — `PUT /api/expenses/665f2a...`
```json
{ "amount": 300 }
```

### Delete expense — `DELETE /api/expenses/665f2a...`
```json
{ "success": true, "message": "Expense deleted" }
```

### Summary — `GET /api/expenses/summary`
```json
{
  "success": true,
  "data": {
    "grandTotal": 550,
    "byCategory": [
      { "category": "Food", "total": 300, "count": 2 },
      { "category": "Transport", "total": 250, "count": 1 }
    ]
  }
}
```

### Error example — missing token
```json
{ "success": false, "message": "Not authorized, token missing" }
```

### Validation error example
```json
{
  "success": false,
  "message": "Validation failed",
  "errors": [ { "field": "amount", "message": "Amount must be a number greater than 0" } ]
}
```

## 🔒 Security Notes

- Passwords are never stored in plain text (bcrypt hash with salt).
- Passwords are excluded from query results by default.
- Users can only access their own expenses (every query is filtered by user id).
- Secrets live in `.env`, which is git-ignored.

## 📄 License

MIT
