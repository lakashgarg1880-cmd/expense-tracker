// Smoke test: calls every endpoint of a RUNNING server and checks the results.
// Usage:  1) start the server (npm run dev)   2) in another terminal: npm test
// Needs Node 18+ (built-in fetch). It creates two throw-away users with random emails.
const BASE = process.env.API_URL || 'http://localhost:5000';
let passed = 0;
let failed = 0;

const check = (name, condition, extra = '') => {
  if (condition) { passed++; console.log(`  PASS  ${name}`); }
  else { failed++; console.log(`  FAIL  ${name} ${extra}`); }
};

const call = async (method, path, body, token) => {
  const res = await fetch(`${BASE}${path}`, {
    method,
    headers: { 'Content-Type': 'application/json', ...(token && { Authorization: `Bearer ${token}` }) },
    body: body ? JSON.stringify(body) : undefined,
  });
  return { status: res.status, body: await res.json() };
};

(async () => {
  const stamp = Date.now();
  const emailA = `a_${stamp}@example.com`;
  const emailB = `b_${stamp}@example.com`;

  console.log('Auth');
  let r = await call('POST', '/api/auth/register', { name: 'A', email: emailA, password: 'secret123' });
  check('register returns 201 + token', r.status === 201 && !!r.body.data.token);
  const tokenA = r.body.data.token;
  r = await call('POST', '/api/auth/register', { name: 'A', email: emailA, password: 'secret123' });
  check('duplicate email rejected (400)', r.status === 400);
  r = await call('POST', '/api/auth/register', { name: '', email: 'bad', password: '1' });
  check('invalid register rejected (400)', r.status === 400);
  r = await call('POST', '/api/auth/login', { email: emailA, password: 'wrong' });
  check('wrong password rejected (401)', r.status === 401);
  r = await call('POST', '/api/auth/login', { email: emailA, password: 'secret123' });
  check('login works (200)', r.status === 200 && !!r.body.data.token);
  r = await call('GET', '/api/auth/me', null, tokenA);
  check('/me returns profile', r.status === 200 && r.body.data.email === emailA);
  r = await call('GET', '/api/auth/me');
  check('/me without token rejected (401)', r.status === 401);
  r = await call('POST', '/api/auth/login', { email: { $gt: '' }, password: 'x' });
  check('NoSQL injection blocked (400)', r.status === 400);

  console.log('Expenses');
  r = await call('POST', '/api/expenses', { title: 'Lunch', amount: 250, category: 'Food', date: '2026-11-02' }, tokenA);
  check('create expense (201)', r.status === 201);
  const id = r.body.data && r.body.data._id;
  await call('POST', '/api/expenses', { title: 'Dinner', amount: 300.5, category: 'Food', date: '2026-11-02T18:30:00Z' }, tokenA);
  await call('POST', '/api/expenses', { title: 'Bus', amount: 50, category: 'Transport', date: '2026-11-03' }, tokenA);
  r = await call('POST', '/api/expenses', { title: 'x', amount: -5 }, tokenA);
  check('negative amount rejected (400)', r.status === 400);
  r = await call('POST', '/api/expenses', { title: 'x', amount: 5, date: '2026-02-30' }, tokenA);
  check('impossible date rejected (400)', r.status === 400);
  r = await call('GET', '/api/expenses?limit=2&page=1', null, tokenA);
  check('pagination works', r.status === 200 && r.body.count === 2 && r.body.total === 3 && r.body.pages === 2);
  r = await call('GET', '/api/expenses?category=Transport', null, tokenA);
  check('category filter works', r.body.total === 1);
  r = await call('GET', '/api/expenses?startDate=2026-11-02&endDate=2026-11-02', null, tokenA);
  check('endDate includes the whole day (Lunch + Dinner)', r.body.total === 2, `got ${r.body.total}`);
  r = await call('GET', '/api/expenses/summary', null, tokenA);
  check('summary totals correct', r.body.data.grandTotal === 600.5 && r.body.data.byCategory[0].category === 'Food');
  r = await call('GET', `/api/expenses/${id}`, null, tokenA);
  check('get one expense', r.status === 200 && r.body.data.title === 'Lunch');
  r = await call('PUT', `/api/expenses/${id}`, { amount: 300 }, tokenA);
  check('update expense', r.status === 200 && r.body.data.amount === 300);
  r = await call('GET', '/api/expenses/123', null, tokenA);
  check('invalid id rejected (400)', r.status === 400);

  console.log('Privacy between users');
  r = await call('POST', '/api/auth/register', { name: 'B', email: emailB, password: 'secret123' });
  const tokenB = r.body.data.token;
  r = await call('GET', `/api/expenses/${id}`, null, tokenB);
  check("user B cannot read user A's expense (404)", r.status === 404);
  r = await call('DELETE', `/api/expenses/${id}`, null, tokenB);
  check("user B cannot delete user A's expense (404)", r.status === 404);
  r = await call('GET', '/api/expenses/summary', null, tokenB);
  check("user B's summary is empty", r.body.data.grandTotal === 0);

  console.log('Delete + errors');
  r = await call('DELETE', `/api/expenses/${id}`, null, tokenA);
  check('delete expense (200)', r.status === 200);
  r = await call('DELETE', `/api/expenses/${id}`, null, tokenA);
  check('delete again -> 404', r.status === 404);
  r = await call('GET', '/api/nothing');
  check('unknown route -> 404', r.status === 404);
  const bad = await fetch(`${BASE}/api/auth/login`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{bad' });
  check('malformed JSON -> 400 (not 500)', bad.status === 400);

  console.log(`\n${passed} passed, ${failed} failed`);
  process.exit(failed === 0 ? 0 : 1);
})().catch((e) => {
  console.error('Could not reach the server. Is it running? (npm run dev)\n', e.message);
  process.exit(1);
});
